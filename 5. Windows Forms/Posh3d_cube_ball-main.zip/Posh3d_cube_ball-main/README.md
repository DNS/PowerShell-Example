# Posh3d_cube_ball
This script is only tested psversion 5.1
My Background, i'm not a coder or advanced powershell scripter, just some n00b scripter. If I would be a coder I would have done this all with some other language. Or I would have used Unity or Blender...
I have some basic skills to do some powershell scripting and I do understand little c-sharp to be able to translate it to powershell code.

I really don't think I'm an advanced powershell scripter even I do share this "for fun" created script, that I do develop continuously. - I have to remember edit this sentence when I stop developing it. :D

This is just my test how to do some 3D graphics with powershell...
And to get more familiar with powershell classes.

Move ball with keys up,down,left,right

Mouselook in camera 2, the ball turns also the camera lookdirection
(Ball not working ok with keys left,right,t,g)

Move skycam with keys w,s,a,d

zoomin/out skycam keys r,f

Change camera view num keys 1,2,3 (Camera3 is responsible to get our unit not to move into the air or below the floor when camera2 is watching up or down)

Ball intersect was not as accurate as I intended, so added some more logic to that.
Add mouse right click to show contextmenu, when right click on models different contextmenu is visible. All have own click actions.

![fun1](/Screenshots/fun1.PNG)
![fun2](/Screenshots/fun2.PNG)
![fun3](/Screenshots/fun3.PNG)

